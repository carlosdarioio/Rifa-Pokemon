
<?php
//NOTA11111111111111111111111111111111111111 UTILIZA SERIALICE PA PASAR TODOS LOS DATOS DLE FORM!!!!!!!!!!!!!
if (!isset($_SESSION)) { session_start(); }
include("funcion.php")
?>
<?php 
//$_SESSION['inputcantidad']=1;
echo $_POST['inputN'];
if(isset($_POST['idloto'])){
include("../Base.php");
 
    //buscando numeracion de loto
  //  $num=lastloto();
if($_POST['idloto']){

    
    $clavebuscadah2XX=mysql_query("SELECT * FROM pokemones where md5(idloto)='$_POST[idloto]'",$conexion) or die("Problemas en el select#count:".mysql_error());
while($row = mysql_fetch_array($clavebuscadah2XX))
{     
        
      
    $txt="pk".$row['id'];
                                                            //lo ultimo que isiste ahora solo falta eidtar 
        //pokes de x evento y cerrar evento
  $clavebuscadah=mysql_query("update pokemones set pokemon='$_POST[$txt]' where id=$row[id]",$conexion) or
die("Problemas en el AJCambios update:".mysql_error());

        ?>
        
             
       <?php
        
       // header('Location: /Lista.php');
    }
    
    echo $txt." Datos actualizados´ ".$_POST['pk14']." idloto,: ".$_POST['idloto910'];
   
 ?>
      
    
     <?php 
    
    
    
    
    }//fin if num
   else{
   echo "<h1>Error</h1>";
   } 

}//fin if
else{echo " Especificar datos";}
?>
        