
<?php
if (!isset($_SESSION)) { session_start(); }
include("../funcion.php")
?>
<?php 
//$_SESSION['usuario']=1;
//echo "n. ".$_POST['inputN']." p ".$_POST['inputP'];
if(isset($_POST['inputN'])){
include("../Base.php");

$clavebuscadah=mysql_query("update usuario set usuario='$_POST[inputN]', contra='$_POST[inputP]' where id = $_SESSION[usuario]",$conexion) or
die("Problemas en el AJCONF update: ".$_POST['inputP'].mysql_error());

        ?>
        
         <script>
        window.location.href = "Configuracion.php?nm=Listo";
    </script>
       
       <?php
        
       // header('Location: /Lista.php');
   
   
 ?>
      
    
     <?php 
    
 

}//fin if
else{echo "Especificar datos";}
?>
        