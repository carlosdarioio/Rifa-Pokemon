<?php
if (!isset($_SESSION)) { session_start(); }
?>
<?php 
//$_SESSION['usuario']=1;

if($_POST['inputN']!="" && isset($_POST['inputC'])){
include("../Base.php");

    
    //buscando numeracion de loto
$clavebuscadah2XX=mysql_query("SELECT count(id) as cantidad  FROM loto order by id desc",$conexion) or die("Problemas en el select#count:".mysql_error());
$num=0;    
    //obteniendo las #id
$num= mysql_fetch_array($clavebuscadah2XX);
//$num= mysql_fetch_array($clavebuscadah2XX)[0];    
        
if($num){
   
    $clavebuscadah=mysql_query("insert into loto(nombre,estado,idusuario) values ('$_POST[inputN]',0,$_SESSION[usuario])",$conexion) or
die("Problemas en el AJCrear insert:".mysql_error());
///    echo 'Datos ingresados'; 
   
 ?>
      <!--form pokes -->
    <div id="pokes" >
    <div class="form-body pal">
    <div class="row">
    <div class="col-md-12">
    <?php   
    //aqui mostraia un form con la lista de pokes aingresar
    for($i=0; $i<$_POST['inputC']; $i++)
    {
  ?>
    
        <div class="form-group">            
            <div class="input-icon right">
              Poke #<?php echo $i+1;?>
                 <input id="poke<?php echo $i;?>" type="text" placeholder="nombre" class="" />
             </div>
        </div>
          
  <?php   
}//fin for num
   ?>
    </div><!-- Fin col-md-->
    </div><!-- Fin row-->
    </div>
    <div class="form-actions text-right pal">
    <button type="submit" id="AgregarG" class="btn btn-primary">
    Agregar</button>

    </div>
    <br>
    <h2>Especificar pokemones a repartir.</h2>
</div>   <!--fin form pokes --> 
    
    <!-- Colocar script-->
    <?//por aqui vbas    ?>
             <!-- sCRIPT PAl agregar pokes-->
         <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <script>
  //  $(document).ready(function() {
        $('#AgregarG').click(function(e) {
            //for php
           // alert('click');
     <?php  for($i=0; $i<$_POST['inputC']; $i++)   {  ?>
            var inputName<?php echo $i; ?> = $('#poke<?php echo $i; ?>').val();
    <?php                                            } ?>        
            //fin for php
            //cabtidad de pokes
            
            var PKcantidad = (0+ <?php echo $_POST['inputC'];?>);
                           
            e.preventDefault();
            
            // alert('click3');
            $.ajax({
                type: 'POST',
                url: 'Ajax/AJPKCrear.php',
                           //aqui en data podrias pasar los datos nick y fc
                data: {
                      <?php  for($i=0; $i<$_POST['inputC']; $i++)   {  ?>
                      inputPK<?php echo $i; ?>:inputName<?php echo $i; ?>,
                       <?php                                            } ?>
                      inputPKC:PKcantidad,
                      id:0},
                success: function(data)
                {
                // alert('clickfin');      
                 $("#pokes").html(data);
                //  document.write(data);
                //window.location.href = 'google.com' + data    
                }
            });
        });
//    });        
            
</script><!-- Fin sCRIPT PAl agregar pokes-->
    
    <!-- Fin Colocar script-->
    
     <?php 
    
    
    
    
    }//fin if num
   else{
   echo "<h1>Error</h1>";
   } 

}//fin if
else{echo "Especificar datos";}
?>
        