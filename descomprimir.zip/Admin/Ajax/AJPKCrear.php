
<?php
if (!isset($_SESSION)) { session_start(); }
include("../funcion.php")
?>
<?php 
//$_SESSION['usuario']=1;

if(isset($_POST['inputPKC'])){
include("../Base.php");

    
    //buscando numeracion de loto
    $num=lastloto();
if($_POST['inputPKC']){

    
    for($i=0; $i<$_POST['inputPKC']; $i++)   { 
        
      
    $txt="inputPK".$i;
                                                            //lo ultimo que isiste ahora solo falta eidtar 
        //pokes de x evento y cerrar evento
  $clavebuscadah=mysql_query("insert into pokemones(pokemon,estado,idloto) values ('$_POST[$txt]',0,$num)",$conexion) or
die("Problemas en el AJCPKrear insert:".mysql_error());

        ?>
        
         <script>
        window.location.href = "Lista.php?nm=Echo";
    </script>
       
       <?php
        
       // header('Location: /Lista.php');
    }
   
 ?>
      
    
     <?php 
    
    
    
    
    }//fin if num
   else{
   echo "<h1>Error</h1>";
   } 

}//fin if
else{echo "Especificar datos";}
?>
        