<?php
if (!isset($_SESSION)) { session_start(); }
?>
<?php 
$_SESSION['usuario']=0;

if($_POST['Name']!="" && $_POST['PS']!=""){
include("../Base.php");
$clavebuscadah2XX=mysql_query("select * from usuario where usuario = '$_POST[Name]' and contra = '$_POST[PS]'",$conexion) or die("Problemas en el select:".mysql_error());
$comprobante=false;    
while($row2XX = mysql_fetch_array($clavebuscadah2XX))
{
 if($row2XX['usuario'] ==$_POST['Name'] and $row2XX['contra'] ==$_POST['PS']){
    $comprobante = true;
     $_SESSION['usuario']=$row2XX['id'];
}
    
    
}//fin while
    
if($comprobante==true){
   
  ?>
    
    <script>
        window.location.href = "Lista.php?nm=<?php echo $_POST['Name']; ?>";
    </script>
    
  <?php   
}    
   else{
   echo "<h1>Usuario o contraseña incorrecto</h1>";
   } 

}//fin if
else{echo "Especificar datos";}
?>
        