<?php include("funcion.php"); include("Base.php");


cabesa();


?>             
            <div id="page-wrapper">
                <!--BEGIN TITLE & BREADCRUMB PAGE-->
                <div id="title-breadcrumb-option-demo" class="page-title-breadcrumb">
                    <div class="page-header pull-left">
                        <div class="page-title">
                        Editar Loto
                        </div>
                    </div>
                   
                    <ol class="breadcrumb page-breadcrumb pull-right">
                        <li><i class="fa fa-home"></i>&nbsp;<a href="dashboard.html">Administracion</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</li>
                        <li class="hidden"><a href="#">Lista</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</li>
                        <li class="active">Creacion de evento    &nbsp; &nbsp; &nbsp;</li>
                    </ol>
                    
                    <div class="clearfix">
                    </div>
                </div>
                
                <!--END TITLE & BREADCRUMB PAGE-->
                <!--BEGIN CONTENT-->
                <div class="page-content">
                    <div id="tab-general">
                        <div class="row mbl">
                            <div class="col-lg-12">
                                
                                            <div class="col-md-12">
                                                <div id="area-chart-spline" style="width: 100%; height: 300px; display: none;">
                                                </div>
                                            </div>
                                
                            </div>

                            <div class="col-lg-12">
                          
    <!--BEGIN CONTENT-->
    <div class="page-content">
        <div id="title-breadcrumb-page" class="row">
            <div class="col-lg-12">

            <!-- Inicio Evento-->
            
            <div class="col-lg-12">
                                        <div class="panel panel-green">
                                            <div class="panel-heading">
                                                Especificar nombre de loto y cantidad de pokes a regalar</div>
                                            <div class="panel-body pan">
                                               <!--POR AQUI VAS_
                                               que tambien pida cantidad de pokes a crear                 
                                               ahora al darle  crear evento
                                               ejecutar ajax pa crearlo evento y dirigirlo 
                                               a especificar pokes
                                               
                                                 -->
                                                 <!--action="Ajax/Crear.php" method="post"--> 
                                                <div id="" >
                                                <div class="form-body pal">
                                                    <div class="row">
                                                        <div class="col-md-12">
                                                          
                                                    <?php
 
    //buscando numeracion de loto
$clavebuscadah2XX=mysql_query("SELECT * FROM loto where md5(id)='$_GET[id]'",$conexion) or die("Problemas en el select#count:".mysql_error());
$num=0;    
    //obteniendo las #id
$num= mysql_fetch_array($clavebuscadah2XX)[0];        
                                                            
                                                    ?>
                                                          
                                                           <!-- Tema-->
                                                            <div class="form-group">
                                                                <label for="inputName" class="control-label">
                                                                    Tema</label>
                                                                <div class="input-icon right">
                                                                    <input id="inputName" type="text" value="<?php echo $num;?>"class="form-control" /></div>
                                                            </div>
                                                            <!-- Fin Tema-->
                                                            
                                                            
                                                            <!-- Pokes-->
                                                                  <?php 

                                                          
//  $conexion=mysql_connect("localhost","root","") or die("Problemas en la conexion");                                                            
$clavebuscadah2XX2=mysql_query("SELECT * FROM pokemones where md5(idloto)='$_GET[id]'",$conexion) or die("Problemas en el select#count:".mysql_error());
while($row = mysql_fetch_array($clavebuscadah2XX2))
{      
      
?>

  
                                    <div class="form-group">            
                                        <div class="input-icon right">
                                          Poke 
                                             <input id="pk<?php echo $row['id'];?>" type="text" value="<?php echo $row['pokemon'];?>" class="" />
                                             <!-- POR AUQI VAS FALTA GUARDAR CAMBIOS ECHOS-->
                                             <!-- OPCIONAL ACTUALIZAR EL ESTADO DE LOS POKES-->
                                         </div>
                                    </div>
                                                            
                                                            <?php } ?>
                                                            <!-- Fin Pokes-->
                                                              <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
  
                                                            
                                                        </div>
                                                        <div class="col-md-12">
                                                            <h1 id="msj" ></h1>
                                                        </div>        
                                                    </div>
                                                                                                                                                
                                                </div>
                                                <div class="form-actions text-right pal">
                                                    <button type="submit" id="GuardarC" class="btn btn-primary">
                                                        Guardar Cambioss</button>
    
                                                </div>
                                                </div>
                                            </div>
                                        </div>
                                       
                                    </div>
               
                <!-- Fin evento-->
            </div><!-- Fin col lg 12-->
        </div>
    </div><!-- Fin page ocntent-->
                            </div>
                        </div>
                    </div>
                </div>
                <!--END CONTENT-->
                <!--BEGIN FOOTER-->
 
    <div id="msj" class="col-md-12 text-center"></div>
      
        <!-- Fin sCRIPT-->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <div id="msj" class="col-md-12 text-center"></div>
         <!-- sCRIPT PAl loggin-->
        <script>
    $(document).ready(function() {
        $('#GuardarC').click(function(e) {
            alert(inputcantidad);
            e.preventDefault();
            $.ajax({
                type: 'POST',
                url: 'AJCambios.php',
                           //aqui en data podrias pasar los datos nick y fc
                data: {     
                    inputN:<?php echo json_encode($('#pk13').val()); ?>,
                      },
               //
            /*    data: {
            
            //NEW LAST HELOW EL UPDATE SE EJEVUTARIA UNA VERZ POR CADA POKE, NO INTENTES PASAR TODOS
            //ACTUALIZA UNO POR UNO------------------------------------------------------------------------------------------------------------------------------------
                    inputN:<?php echo "$('#pk13').val()";?>,
                      },*/
                success: function(data)
                {
                      
                 $("#msj").html(data);
                //  document.write(data);
                //window.location.href = 'google.com' + data    
                }
            });
        });
    });
            
            
</script><!-- Fin sCRIPT-->
      
      
       <?php
        //       echo $_SESSION['usuario'];
                ?>
       <h1>ujhuih</h1>
        
            
           <?php
                
                pie();
                
                ?>