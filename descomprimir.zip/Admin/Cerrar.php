
<?php
if (!isset($_SESSION)) { session_start(); }
?>
<?php 

if(isset($_GET['id'])){
include("Base.php");
 
    //buscando numeracion de loto
  //  $num=lastloto();
if($_GET['id']){

    
    $clavebuscadah2XX=mysql_query("update loto set estado=1 where md5(id)='$_GET[id]'",$conexion) or die("Problemas en cerrar evento:".mysql_error());

    header( 'Location: Lista.php' );
  

    }
    
    }
    
    
 ?>