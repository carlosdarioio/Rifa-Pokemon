<?php include("funcion.php"); include("Base.php");


cabesa();


?>             
            <div id="page-wrapper">
                <!--BEGIN TITLE & BREADCRUMB PAGE-->
                <div id="title-breadcrumb-option-demo" class="page-title-breadcrumb">
                    <div class="page-header pull-left">
                        <div class="page-title">
                       Configuracion de usuario   
                        </div>
                    </div>
                   
                    <ol class="breadcrumb page-breadcrumb pull-right">
                        <li><i class="fa fa-home"></i>&nbsp;<a href="Lista.php">Administracion</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</li>
                        <li class="hidden"><a href="Lista.php">Lista</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</li>
                        <li class="active">Configuracion    &nbsp; &nbsp; &nbsp;</li>
                    </ol>
                    
                    <div class="clearfix">
                    </div>
                </div>
                
                <!--END TITLE & BREADCRUMB PAGE-->
                <!--BEGIN CONTENT-->
                <div class="page-content">
                    <div id="tab-general">
                        <div class="row mbl">
                            <div class="col-lg-12">
                                
                                            <div class="col-md-12">
                                                <div id="area-chart-spline" style="width: 100%; height: 300px; display: none;">
                                                </div>
                                            </div>
                                
                            </div>

                            <div class="col-lg-12">
                          
    <!--BEGIN CONTENT-->
    <div class="page-content">
        <div id="title-breadcrumb-page" class="row">
            <div class="col-lg-12">

            <!-- Inicio Evento-->
            <!-- Obteniendo dato suser-->
            <?php 
                $clavebuscadah2XX=mysql_query("select * from usuario where id = $_SESSION[usuario]",$conexion) or die("Problemas en el select Conf1:".mysql_error());
                $user="";
                $contraS="";
while($row2XX = mysql_fetch_array($clavebuscadah2XX))
{
    $user=$row2XX['usuario'];
    $contraS=$row2XX['contra'];
}
                ?>
           
            <!--Fin  Obteniendo dato suser-->
            
            
            <div class="col-lg-12">
                                        <div class="panel panel-green">
                                            <div class="panel-heading">
                                                Especificar nombre de usuario y contraseña</div>
                                            <div class="panel-body pan">
                                              
                                                 <!--action="Ajax/Crear.php" method="post"--> 
                                                <div id="cuerpo" >
                                                <div class="form-body pal">
                                                    <div class="row">
                                                        <div class="col-md-12">
                                                            <div class="form-group">
                                                                <label for="inputName" class="control-label">
                                                                    Usuario</label>
                                                                <div class="input-icon right">
                                                                    <input id="inputName" type="text" value="<?php echo $user; ?>" class="form-control" /></div>
                                                            </div>
                                                            
                                                            <div class="form-group">
                                                                <label for="inputName" class="control-label">
                                                                    Contraseña</label>
                                                                <div class="input-icon right">
                                                                <input id="inputPSW" type="text" value="<?php echo $contraS; ?>" class="form-control" /></div>
                                                            </div>
                                                            
                                                            
                                                        </div>
                                                        
                                                    </div>
                                                                                                                                                
                                                </div>
                                                <div class="form-actions text-right pal">
                                                    <button type="submit" id="entrarE" class="btn btn-primary">
                                                        Actualizar Datos</button>
    
                                                </div>
                                                    <br>
                                                   <h1 id="msj"class="msj"></h1>
                                                </div>
                                            </div>
                                        </div>
                                       
                                    </div>
               
                <!-- Fin evento-->
            </div><!-- Fin col lg 12-->
        </div>
         <?php  if(isset($_GET['nm']))
              {
                 if($_GET['nm']=="Listo"):
                    echo "<h1>Datos Actualizados.</h1>";
                endif;
               }
        ?>
    </div><!-- Fin page ocntent-->
                           
                            </div>
                            
                        </div>
                        
                    </div>                 
      
      
                </div>
                <!--END CONTENT-->
                <!--BEGIN FOOTER-->
 <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <div id="msj" class="col-md-12 text-center"></div>
         <!-- sCRIPT PAl loggin-->
        <script>
    $(document).ready(function() {
        $('#entrarE').click(function(e) {
            var Name = $('#inputName').val();
            var PSW= $('#inputPSW').val();                   
            e.preventDefault();
            $.ajax({
                type: 'POST',
                url: 'Ajax/AJConf.php',
                           //aqui en data podrias pasar los datos nick y fc
                data: {inputN:Name,inputP:PSW},
                success: function(data)
                {
                      
                 $("#cuerpo").html(data);
                //  document.write(data);
                //window.location.href = 'google.com' + data    
                }
            });
        });
    });
            
            
</script><!-- Fin sCRIPT PAl loggin-->
      
      
      
       <?php
                
               
                
        //       echo $_SESSION['usuario'];
                ?>
      
        
            
           <?php
                
                pie();
                
                ?>