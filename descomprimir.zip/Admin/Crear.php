<?php include("funcion.php"); include("Base.php");


cabesa();


?>             
            <div id="page-wrapper">
                <!--BEGIN TITLE & BREADCRUMB PAGE-->
                <div id="title-breadcrumb-option-demo" class="page-title-breadcrumb">
                    <div class="page-header pull-left">
                        <div class="page-title">
                        Crear Loto   
                        </div>
                    </div>
                   
                    <ol class="breadcrumb page-breadcrumb pull-right">
                        <li><i class="fa fa-home"></i>&nbsp;<a href="Lista.php">Administracion</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</li>
                        <li class="hidden"><a href="Lista.php">Lista</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</li>
                        <li class="active">Creacion de loto    &nbsp; &nbsp; &nbsp;</li>
                    </ol>
                    
                    <div class="clearfix">
                    </div>
                </div>
                
                <!--END TITLE & BREADCRUMB PAGE-->
                <!--BEGIN CONTENT-->
                <div class="page-content">
                    <div id="tab-general">
                        <div class="row mbl">
                            <div class="col-lg-12">
                                
                                            <div class="col-md-12">
                                                <div id="area-chart-spline" style="width: 100%; height: 300px; display: none;">
                                                </div>
                                            </div>
                                
                            </div>

                            <div class="col-lg-12">
                          
    <!--BEGIN CONTENT-->
    <div class="page-content">
        <div id="title-breadcrumb-page" class="row">
            <div class="col-lg-12">

            <!-- Inicio Evento-->
            
            <div class="col-lg-12">
                                        <div class="panel panel-green">
                                            <div class="panel-heading">
                                                Especificar nombre de loto y cantidad de pokes a regalar</div>
                                            <div class="panel-body pan">
                                               <!--POR AQUI VAS_
                                               que tambien pida cantidad de pokes a crear                 
                                               ahora al darle  crear evento
                                               ejecutar ajax pa crearlo evento y dirigirlo 
                                               a especificar pokes
                                               
                                                 -->
                                                 <!--action="Ajax/Crear.php" method="post"--> 
                                                <div id="cuerpo" >
                                                <div class="form-body pal">
                                                    <div class="row">
                                                        <div class="col-md-12">
                                                            <div class="form-group">
                                                                <label for="inputName" class="control-label">
                                                                    Tema</label>
                                                                <div class="input-icon right">
                                                                    <input id="inputName" type="text" placeholder="Evento" class="form-control" /></div>
                                                            </div>
                                                            
                                                            <div class="form-group">
                                                                <label for="inputName" class="control-label">
                                                                    Cantidad</label>
                                                                <div class="input-icon right">
                                                                <input id="inputCantidad" type="text" placeholder="#" class="form-control" /></div>
                                                            </div>
                                                            
                                                            
                                                        </div>
                                                        
                                                    </div>
                                                                                                                                                
                                                </div>
                                                <div class="form-actions text-right pal">
                                                    <button type="submit" id="entrarE" class="btn btn-primary">
                                                        Crear Evento</button>
    
                                                </div>
                                                    <br>
                                                    <h2>Especificar Tema y cantidad de pokes a repartir.</h2>
                                                </div>
                                            </div>
                                        </div>
                                       
                                    </div>
               
                <!-- Fin evento-->
            </div><!-- Fin col lg 12-->
        </div>
    </div><!-- Fin page ocntent-->
                            </div>
                        </div>
                    </div>
                </div>
                <!--END CONTENT-->
                <!--BEGIN FOOTER-->
 <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <div id="msj" class="col-md-12 text-center"></div>
<!-- sCRIPT PAl loggin-->
<script>
    $(document).ready(function() {
        $('#entrarE').click(function(e) {
            var inputName = $('#inputName').val();
            var inputcantidad = $('#inputCantidad').val();                   
            e.preventDefault();
            $.ajax({
                type: 'POST',
                url: 'Ajax/AJCrear.php',
                           //aqui en data podrias pasar los datos nick y fc
                data: {inputN:inputName,inputC:inputcantidad},
                success: function(data)
                {
                      
                 $("#cuerpo").html(data);
                //  document.write(data);
                //window.location.href = 'google.com' + data    
                }
            });
        });
    });
            
            
</script><!-- Fin sCRIPT PAl loggin-->
      
      
      
       <?php
        //       echo $_SESSION['usuario'];
                ?>
      
        
            
           <?php
                
                pie();
                
                ?>