<?php include("funcion.php"); include("Base.php");


cabesa();


?>             
            <div id="page-wrapper">
                <!--BEGIN TITLE & BREADCRUMB PAGE-->
                <div id="title-breadcrumb-option-demo" class="page-title-breadcrumb">
                    <div class="page-header pull-left">
                        <div class="page-title">
                     <?php echo $_SESSION['usuario']; ?>    Historial de Lotos   <?php //echo $_GET['nm']; ?>
                        </div>
                    </div>
                    <!--Boton nuevo -->
                    <div class="page-toolbar pull-right">
                           <a href="Crear.php" class="btn btn-blue">Crear Loto</a>
                    </div>  
                    <!--Fin Boton nuevo -->
                    <ol class="breadcrumb page-breadcrumb pull-right">
                        <li><i class="fa fa-home"></i>&nbsp;<a href="Lista.php">Administracion</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</li>
                        <li class="hidden"><a href="#">Lista</a>&nbsp;&nbsp;<i class="fa fa-angle-right"></i>&nbsp;&nbsp;</li>
                        <li class="active">Historial de Lotos    &nbsp; &nbsp; &nbsp;</li>
                    </ol>
                    
                    <div class="clearfix">
                    </div>
                </div>
                
                <!--END TITLE & BREADCRUMB PAGE-->
                <!--BEGIN CONTENT-->
                <div class="page-content">
                    <div id="tab-general">
                        <div class="row mbl">
                            <div class="col-lg-12">
                                
                                            <div class="col-md-12">
                                                <div id="area-chart-spline" style="width: 100%; height: 300px; display: none;">
                                                </div>
                                            </div>
                                
                            </div>

                            <div class="col-lg-12">
                          
    <!--BEGIN CONTENT-->
    <div class="page-content">
       <p class="lead" id="lead"></p>
        <div id="title-breadcrumb-page" class="row">
            <div class="col-lg-12">

            <!-- Inicio Evento-->
            <?php
$clavebuscadah2XX=mysql_query("select * from loto where idusuario = $_SESSION[usuario] order by id desc",$conexion) or die("Problemas en el select Lista1:".mysql_error());    
while($row2XX = mysql_fetch_array($clavebuscadah2XX))
{
 if($row2XX['estado'] ==0){
//    $comprobante = false;
    
                ?>    
            <div class="page-title-breadcrumb"> <!-- option-demo-->
                <div class="page-header pull-right">
                    <div class="page-toolbar">
                        <!--<a href="Cambios.php?id=<?php echo md5($row2XX['id']);?>" data-hover="tooltip" title="Send Message" class="btn btn-yellow">
                        Editar</a>
                        &nbsp;
                        <div class="btn-group">
                            <button type="button" class="btn btn-orange dropdown-toggle">
                                Cerrar &nbsp;
                            </button>
                        </div>-->
                         &nbsp;
                         
                         
                         <div class="btn-group">
                            <a href="http://competitivopkm.host56.com/pokemon/index.php?lot=<?php echo md5($row2XX['id']);?>" class="btn btn-help dropdown-toggle">
                                Visualizar &nbsp;
                            </a>
                        </div>
                         
                         
                        <div class="btn-group">
                            <button type="button" onclick="Compartir('<?php echo md5($row2XX['id']);?>')" class="btn btn-info dropdown-toggle">
                                Compartir &nbsp;
                            </button>
                        </div>
                        
                        <div class="btn-group">
                            <a href="Cerrar.php?id=<?php echo md5($row2XX['id']);?>" class="btn btn-yellow dropdown-toggle">
                                Cerrar &nbsp;
                            </a>
                        </div>
                        
                    </div>
                </div>
                    <!-- Contenido resumen evento-->
                    <ol class="breadcrumb page-breadcrumb pull-left">
                        <li>Evento<i class="fa fa-angle-right"></i>&nbsp;</li>
                        <li><a href="#"><?php echo $row2XX['nombre'];?></a>&nbsp;&nbsp;
                            
                            &nbsp;</li>
                        
                    </ol>
                    <!-- Fin contenido resumen evento-->
                    <div class="clearfix">
                    </div>
                   
                </div>
                <?php } }?>
                <!-- Fin evento-->
            </div><!-- Fin col lg 12-->
        </div>
    </div><!-- Fin page ocntent-->
                            </div>
                        </div>
                    </div>
                </div>
                <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
                <!--END CONTENT

                <!--BEGIN FOOTER-->
             <script>
                function Compartir(X){
                   // alert('https://glomerular-fours.000webhostapp.com/pokemon/index.php/?lot='+X); 25 06 2017 update to competitivopkm.host56.com
                    $('#lead').html("<small class='alert alert-danger'>Direccion:</small><br><br><br><small class='alert alert-success'> https://competitivopkm.host56.com/pokemon/index.php?lot="+X+"</small>");
                } 
                </script>
            <hr>
             
           <?php
                
                pie();
                
                ?>