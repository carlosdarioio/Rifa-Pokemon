<!DOCTYPE html>
<html lang="en">
<head>
    <title>Login | Competitivo POkemon</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link type="text/css" href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,700italic,800italic,400,700,800">
    <link type="text/css" rel="stylesheet" href="http://fonts.googleapis.com/css?family=Oswald:400,700,300">
    <link type="text/css" rel="stylesheet" href="styles/font-awesome.min.css">
    <link type="text/css" rel="stylesheet" href="styles/bootstrap.min.css">
    <link type="text/css" rel="stylesheet" href="styles/animate.css">
    <link type="text/css" rel="stylesheet" href="styles/all.css">
    <link type="text/css" rel="stylesheet" href="styles/main.css">
    <link type="text/css" rel="stylesheet" href="styles/style-responsive.css">
</head>
<body style="background: url('images/bg/bg.png') center center fixed;">
    <div class="page-form">
        <div class="panel panel-blue">
            <div class="panel-body pan">
                <div  class="form-horizontal">
                <div class="form-body pal">
                    <div class="col-md-12 text-center">
                        <h1 style="margin-top: -90px; font-size: 48px;">
                            Loto Pokemon</h1>
                        <br />
                    </div>
                    <div class="form-group">
                        <div class="col-md-3">
                            <img src="images/avatar/profile-pic.png" class="img-responsive" style="margin-top: -35px;" />
                        </div>
                        <div class="col-md-9 text-center">
                            <h1>
                               Especificar datos.</h1>
                            <br />
                            <p>
                                Loteria requiere inicio de sesion</p>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="inputName" class="col-md-3 control-label">
                            Nombre de usuario:</label>
                        <div class="col-md-9">
                            <div class="input-icon right">
                                <i class="fa fa-user"></i>
                                <input id="inputName" type="text" placeholder="" class="form-control" /></div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="inputPassword" class="col-md-3 control-label">
                            Contraseña:</label>
                        <div class="col-md-9">
                            <div class="input-icon right">
                                <i class="fa fa-lock"></i>
                                <input id="inputPassword" type="password" placeholder="" class="form-control" /></div>
                        </div>
                    </div>
                    <div class="form-group mbn">
                        <div class="col-lg-12" align="right">
                            <div class="form-group mbn">
                                <div class="col-lg-3">
                                    &nbsp;
                                </div>
                                <div class="col-lg-9">
                                    <a href="https://www.facebook.com/groups/1079498115484034/" class="btn btn-default">Regresar</a>&nbsp;&nbsp;
                                    <button type="submit" id="entrarxx" class="btn btn-default">
                                        Entrar</button>
                             
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                </div><!-- era form-->
            </div>
        </div>
    </div>
     <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <div id="msj" class="col-md-12 text-center"></div>
         <!-- sCRIPT PAl loggin-->
        <script>
    $(document).ready(function() {
        $('#entrarxx').click(function(e) {
            var inputName = $('#inputName').val();
            var inputPassword = $('#inputPassword').val();                   
            e.preventDefault();
            $.ajax({
                type: 'POST',
                url: 'Ajax/Loggin.php',
                           //aqui en data podrias pasar los datos nick y fc
                data: {Name:inputName,PS:inputPassword},
                success: function(data)
                {
                      
                 $("#msj").html(data);
                //  document.write(data);
                //window.location.href = 'google.com' + data    
                }
            });
        });
    });
            
            
</script>
        <!-- Fin sCRIPT PAl loggin-->
    
</body>
</html>
