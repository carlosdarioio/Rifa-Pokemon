<html>
    
    
    <body>
    <?php
                
  session_start();
  unset($_SESSION["usuario"]); 
  session_destroy();
  header("Location: Login.php");
  exit;
        
        ?>
    </body>    
</html>